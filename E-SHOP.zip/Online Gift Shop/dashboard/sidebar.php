<?php
echo '<ul>
<li> <a href="./"><i class="fas fa-home"></i><span>Home</span> </a></li>
<li> <a href="./cart.php"><i class="fas fa-shopping-cart"></i><span>Cart</span> </a>
</li>
<li> <a href="./customers.php"><i class="fas fa-users"></i><span>Customers</span> </a>
</li>

<li><a href="./logout.php"><i class="fas fa-sign-out-alt"></i><span>logout</span> </a></li>
</ul>';