<?php
echo '<!-- footer -->
<!-- developed by mb_mishu -->
<footer class="footer-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <p class=" text-uppercase  text-center">&reg; 2022 MADE FOR
                    <span> E-shop</span> &nbsp; by &nbsp;<span> <a href="https://www.facebook.com/profile.php?id=100052548154054&mibextid=LQQJ4d"
                            target="_blank"> Kaushik Das</a> </span>
                </p>
            </div>
        </div>
    </div>

</footer>';